let count: number = 0;

for (let index = 0; index < 10; index++) {
  count = index;
  console.log(count);
  count = 0;
}
