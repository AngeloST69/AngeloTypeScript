
function imprimorDatos (
    data: {
        userName : string,
        email : string
    }
): void {
    console.log(`Tu nombre es: ${data.userName}, y wl email regresa: ${data.email}`)
}


imprimorDatos ({userName: "Diego", email: "diego@12hotmail.com"});



type userData = {
    nombre : string,
    edad: number,
    email: string,
    telefono: string
}

let userList: userData[] = [];

userList.push ({
    nombre: "Diego",
    edad: 29,
    email: "diego@45gmail.com",
    telefono: "0999999999"

    });

    userList.push ({
        nombre: "Kevin",
        edad: 30,
        email: "kevin@4gmail.com",
        telefono: "0992456789"
    
        });
        console.log(userList[0]);