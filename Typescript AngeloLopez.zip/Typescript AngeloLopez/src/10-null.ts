//Null y Undefine

let myVar = null;
let otroVar = undefined
console.log("type of otroVar:", typeof(otroVar), "Type of myVar: ", typeof(myVar));

let myNull : null = null;
let myUdefined: undefined = undefined;
console.log("type of myNull:", typeof(myNull), "Type of myNull: ", typeof(myNull));

let myNumber: number|null = null;
myNumber = 60;
console.log("Type of myNumer: ",typeof(myNumber));
console.log("myNumber", myNumber);

let myString: string | undefined = undefined;
console.log("type of myString: ",typeof(myString));
console.log ("myString", myString);

myString = "hola 15";
console.log("type of myString: ",typeof(myString));
console.log ("myString", myString);


