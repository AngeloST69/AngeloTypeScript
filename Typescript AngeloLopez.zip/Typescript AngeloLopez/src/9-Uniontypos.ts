// UNIO DE TIPO DE DATOS
let userId: number | string;

userId = "Karen";
console.log(userId);
userId = 500;
console.log(userId);

(() => {
  function hello(id: number | string) {
    if (typeof id === "number") {
      console.log(`Su ID es: ${id}`);
    } else {
      console.log(`Su usuario es: ${id}`);
    }
  };
  hello("Karen")
  hello(300)
})();
