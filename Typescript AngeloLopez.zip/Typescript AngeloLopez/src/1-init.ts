console.log("Hola");

var numero1: number = 10;
var numero2: number = 12;

if(numero1 = numero2){
  console.log("Son iguales");
}else{
  console.log("No son iguales");
}
