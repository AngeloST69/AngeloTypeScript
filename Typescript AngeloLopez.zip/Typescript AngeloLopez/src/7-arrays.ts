let array1 = [1,2,3,4,5,6];

/* Metodo Push para agregar un elemento al final del array */

array1.push(45);
console.log(array1);

// array1.push("45");

let meses = ["enero", "febrero", "marzo", "abril"];
// let ejemploMultiplicacoin = meses.map(item => item * 2)

let array2:(boolean|number|string)[] = [true, 234, "ejemplo"];
let array3 = [23, true, "ejemplo"];
console.log(array2);
console.log(array3);

let multiplicacion =  array1.map(item => item * 2);
console.log(multiplicacion);
