export type Sizes = 'S' | 'M' | 'L' | 'XL' | 'XXL';


export type Data = {
  nombre : string,
  edad : number,
  email : string,
  telefono : string
}

export type Product = {
  precio : number,
  name : string,
  stock : number,
}
