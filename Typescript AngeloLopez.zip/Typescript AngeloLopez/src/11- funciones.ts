// funciones en ts

type Sizes = 's' |'M'|'L'|'XL';
type Genero = 'hombre' |'mujer';

function crearProducto(
  nombre: string,
  costo : number,
  genero : Genero,
  talla : Sizes,
  stock : number | null,
  createdAt : Date
  ){

  return{
    nombre,
    genero,
    costo,
    talla,
    stock,
    createdAt
  }
  };

const producto1 = crearProducto(
  "Zpato deportivo",
  70,
  "hombre",
  "XL",
  null,
  new Date("02/02/03"))

 console.log(producto1);
 console.log(producto1.createdAt);

// fgfgdfgfdgdfgfdgf


 function crearProducto1(
  nombre: string,
  costo : number,
  genero : Genero,
  createdAt : Date,
  talla? : Sizes,
  stock? : number | null,
  ){

  return{
    nombre,
    genero,
    costo,
    talla,
    stock,
    createdAt
  }
  };

  const producto2 = crearProducto1(
    "Zpato deportivo",
    70,
    "hombre",
    new Date("02/02/03"),
    "XL",
    null
    )

 console.log(producto2);
 console.log(producto2.createdAt);

 //retorno en las funciones 

 // funciones tipo void

 function imprimirNombre (
  yourName :string

 ) : void {
console.log(`Bienvenido ${yourName} as TS`)
 }

 imprimirNombre("kEVIN");


 // funcion de retorno
let resultado = 0

 function operacion1 (
  a : number,
  b : number) : number {
     return a + b;

  };

  let ejemploFuncion = console.log(operacion1 (45, 58));

 

  function clasificador (
    a: number,
    b: number,
    c: number,):  number |string {
      if (a>b || a<c) {
        return a

      }
      if (b>a && b<c){
        return c;
      }
      if (c>a && c<b) {
        return c;
      }
      else {
        return `Los numeros son iguales`
      }
    }

    let clasificador1 = console.log(clasificador(7,6,6));
